package main;


import java.util.HashMap;

public class EndPoint {

	int Ld;
	int K;
	HashMap<Integer, Integer> latencies; // cache server id -> latency
	
}
