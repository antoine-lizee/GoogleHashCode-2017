package main;


import java.util.HashMap;

public class EndPoint {

	public int Ld;
	int K;
	public HashMap<Integer, Integer> latencies; // cache server id -> latency
	
}
