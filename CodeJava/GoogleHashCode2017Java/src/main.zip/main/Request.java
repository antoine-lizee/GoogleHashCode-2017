package main;

public class Request {
	int Rv, Re, Rn;
	int id;
	
	CacheServer serverUsed;
	
	// current gain for this request
	public int computeRequestScore(Problem problem) {
		if(serverUsed == null) {
			return 0;
		} else {
			EndPoint endpoint = problem.endpoints.get(Re);
			return Rn * (endpoint.Ld - endpoint.latencies.get(serverUsed.serverId));
		}
	}
	
}
