package main;

import java.util.HashSet;

public class CacheServer {

	int serverId;
	HashSet<Integer> videos; // ids of videos stored in this server
	private int spaceTaken;
	
	// returns 0 if added, 1 if video was there, 2 if not enough capacity
	public boolean putVideo(int videoId, Problem problem) {
		
		int videoSize = problem.videoSizes[videoId];
		
		if(videos.contains(videoId)) {
			System.out.println("error: video already there");
			return false;
		} else if(spaceTaken+videoSize > problem.X) {
			System.out.println("error: not enough space");
			return false;
		}
		
		spaceTaken += videoSize;
		videos.add(videoId);
		
		// when we put the video, some requests will use this one
		for(Request request : problem.videoIdToRequests.get(videoId)) {
			EndPoint endpoint = problem.endpoints.get(request.Re);
			
			if(!endpoint.latencies.containsKey(this.serverId)) {
				continue; // the request's endpoint and the cache server are not connected 
			}
			
			// latency to current server
			int currentLatency = endpoint.Ld;
			if(request.serverUsed != null) {
				currentLatency = endpoint.latencies.get(request.serverUsed.serverId);
			}
			
			int newLatency = endpoint.latencies.get(this.serverId);
			
			if(newLatency < currentLatency) {
				request.serverUsed = this;
			}
			
		}
		
		return true;
	}
	
	
	public CacheServer(int id) {
		serverId = id;
		videos = new HashSet<Integer>();
		spaceTaken = 0;
	}
	
	public int getSpaceTaken() {
		return spaceTaken;
	}
	
	
}
