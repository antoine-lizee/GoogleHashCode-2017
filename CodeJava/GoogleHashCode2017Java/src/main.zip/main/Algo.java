package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.*;

public class Algo {
	
	Problem problem;
	
	HashMap<Integer, CacheServer> caches; // cache server id (0<=c<C) -> list of video ids (0<=v<V)
	int[] requestScores; // of size R, element i score has id=i 
	
	public void printToFile(File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
	 	BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
	 
		bw.write(Integer.toString(caches.size()));
		bw.newLine();
		for(Map.Entry<Integer, CacheServer> entry : caches.entrySet()) {
			StringBuilder sb =new StringBuilder();
			sb.append(entry.getKey());
			
			for(Integer videoId : entry.getValue().videos) {
				sb.append(" "+videoId);
			}
			
			
			bw.write(sb.toString());
			bw.newLine();
		}
	 	bw.close();
	 	
	 	System.out.println(String.format("Saved at: %s", file.getPath()));
	}
	
	public boolean checkCorrect() {
		
		for(Map.Entry<Integer, CacheServer> entry : caches.entrySet()) {
			
			CacheServer cs = entry.getValue();
			
			int sizeInServer = cs.getSpaceTaken();
			
			if(sizeInServer > problem.X) {
				System.out.println("Too much at server: " + cs.serverId);
				return false;
			}
			
		}
		
		return true;
	}
	
	
	public long computeScore() {
		long n=0;
		for(Request request : problem.requests) {
			n += request.computeRequestScore(problem);;
		}
		
		if(n<0) {
			System.out.println("score below 0: " +n);
		}
		
		return n;
	}
	
	public int computeScoreFinal() {
		
		double score = computeScore();
		
		int numRequests = 0;
		for(Request request : problem.requests) {
			numRequests += request.Rn;
		}
		
		double d = score / numRequests;
		int result = (int) (d*1000);
		return result;
	}
	
	public int computeRequestScoreOld(Request request) {
		
		// find the cache servers that have the video and are connected to the endpoint
		EndPoint endpoint = problem.endpoints.get(request.Re);
		
		int minLatency = endpoint.Ld; // latency to datacenter
		CacheServer bestCacheServer = null;
		
		for(int serverId : endpoint.latencies.keySet()) {
			
			CacheServer cs = caches.get(serverId);
			boolean serverHasVideo = cs.videos.contains(request.Rv);
			
			if(serverHasVideo) {
				int latency = endpoint.latencies.get(cs.serverId);
				if(latency < minLatency) {
					minLatency = latency;
					bestCacheServer = cs;
				}
			}
		}
		
		
		//System.out.println(String.format("latency: %d, server: %d", minLatency, bestCacheServer==null ? -1 : bestCacheServer.serverId ));
		
		if(bestCacheServer != null) {
			request.serverUsed = bestCacheServer;
		}
		
		int score = request.Rn * (endpoint.Ld - minLatency);
		
		
		
		return score;
	}
	
	
	
	
	
	
}
