package main;

import java.io.File;
import java.io.IOException;
import java.util.*;


public class Manu {

	public static void DoAlgo0(Algo algo, int iterations) {
		
		algo.caches = new HashMap<Integer, CacheServer>();
		
		// video 0
		CacheServer alloc0 = new CacheServer(0);
		alloc0.putVideo(2, algo.problem);
		algo.caches.put(alloc0.serverId, alloc0);
		
		// video 1
		CacheServer alloc1 = new CacheServer(1);
		alloc1.putVideo(1, algo.problem);
		alloc1.putVideo(3, algo.problem);
		algo.caches.put(alloc1.serverId, alloc1);
		
		// video 2
		CacheServer alloc2 = new CacheServer(2);
		alloc2.putVideo(0, algo.problem);
		alloc2.putVideo(1, algo.problem);
		algo.caches.put(alloc2.serverId, alloc2);
		
	}
	
	public static void DoAlgo1(Algo algo, int innerIter, int outerIter) {
		
		for(int csId = 0; csId < algo.problem.C; csId++) {
			CacheServer cs = new CacheServer(csId);
			algo.caches.put(csId, cs);
		}
		
		Random rn = new Random(23); // repeatable
    	
    	for(int n=0; n<outerIter; n++) {
    		
    		/*
    		if(!algo.checkCorrect()) {
    			System.out.println("error");
    			return;
    		}*/
    		
    		if(n%(1+outerIter/100)==0 && n > 0) {
    			int scoreFinal = algo.computeScoreFinal();   
    			System.out.println(n + " iterations, current score final: " + scoreFinal);
    		}
    		
    		// for each video, find the server where we gain most if we put it there
    		// put the video with the best gain in the best spot
    		
    		int bestVideoId = -1;
    		CacheServer bestServer = null;
    		int bestGain = -1;
    		
    		for(int videoId=0; videoId<algo.problem.V; videoId++) {
    			
    			CacheServer bestServerForThisVideo = null;
    			int bestGainForThisVideo = -1;
    			
    			for(int serverId=0; serverId<algo.problem.C; serverId++) {
    				CacheServer cs = algo.caches.get(serverId);
    				int gain = gainPut(videoId, cs, algo.problem);
    				if(gain > bestGainForThisVideo) {
    					bestGainForThisVideo = gain;
    					bestServerForThisVideo = cs;
    				}
    			}
    			
    			if(bestGainForThisVideo > bestGain) {
    				bestGain = bestGainForThisVideo;
    				bestVideoId = videoId;
    				bestServer = bestServerForThisVideo;
    			}
    			
    			if(n<10 && bestServerForThisVideo!=null) {
    				bestServerForThisVideo.putVideo(videoId, algo.problem);
    			}
    		}
    		
    		if(n>10 && bestVideoId >= 0) {
    			// do put the video in the server
    			bestServer.putVideo(bestVideoId, algo.problem);
    		}
    		
    		/*
    		// take a random request
    		Request request = algo.problem.requests.get(rn.nextInt(algo.problem.requests.size()));
    		int videoSize = algo.problem.videoSizes[request.Rv];
    		
    		if(videoSize > algo.problem.X) {
				continue;
			}
    		
    		EndPoint endpoint = algo.problem.endpoints.get(request.Re);
    		//CacheServer currentServer = request.serverUsed;
    		
    		// find a better server to cache video for this request
    		Set<Integer> otherPossibleServers =  endpoint.latencies.keySet();
    		
    		for(int serverId : otherPossibleServers) {
    			
    			CacheServer possibleServer = algo.caches.get(serverId);
    			
    			if(possibleServer.videos.contains(request.Rv)) {
    				continue;
    			}
    			
    			for(int _=0; _<innerIter; _++) {
    				
    				int takenSize = possibleServer.getSpaceTaken();
    	    		
    	    		// take out random videos until its legal to put this one
    	    		ArrayList<Integer> videosTakenOut = new ArrayList<Integer>();
    	    		
    	    		while(takenSize + videoSize > algo.problem.X) {
    	    			int videoOut = randomFromSet(possibleServer.videos, rn);
    	    			possibleServer.videos.remove(videoOut);
    	    			videosTakenOut.add(videoOut);
    	    			
    	    			int videoOutSize = algo.problem.videoSizes[videoOut]; 
    	    			takenSize -= videoOutSize;
    	    		}
    				
    	    		// add this video 
    	    		possibleServer.videos.add(request.Rv);
    	    		takenSize += videoSize;
    				
    				// Recompute score for all affected requests
    	    		ArrayList<Request> affected = new ArrayList<Request>();
    	    		affected.add(request);
    	    		for(int videoId : videosTakenOut) {
    	    			for(Request rq : algo.problem.videoIdToRequests.get(videoId)) {
    	    				affected.add(rq);
    	    			}
    	    		}
    	    		
    	    		for(Request rq : affected) {
    	    			algo.requestScores[rq.id] = algo.computeRequestScore(rq);
    	    		}
    	    		int newScore = algo.computeScore(); 
    	    		
    	    		if(newScore < currentScore || (newScore==currentScore && rn.nextInt(2)==0)) {
    	    			// revert changes
    	    			possibleServer.videos.remove(request.Rv);
    	    			for(int videoId : videosTakenOut) {
    	    				possibleServer.videos.add(videoId);
        	    		}
    	    			
    	    			
    	    			for(Request rq : affected) {
        	    			algo.requestScores[rq.id] = algo.computeRequestScore(rq);
        	    		}
    	    			
    	    			
    	    		} else {
    	    			// keep modification
    	    			currentScore = newScore; 
    	    			
    	    		}
    	    		
    			}
    			
    			
    		}*/
    		
    		
    		 
    	}
		
		
	}
	
	// gain if we put this video in this server, -1 if already there of not enough space
	private static int gainPut(int videoId, CacheServer cacheServer, Problem problem) {
		
		if(cacheServer.videos.contains(videoId)) {
			return -1;
		}
		
		int videoSize = problem.videoSizes[videoId];
		
		if(cacheServer.getSpaceTaken() + videoSize > problem.X) {
			return -1;
		}
		
		// when we put the video here in this server, we must look at all the requests using this video
		// and see if it changes their route
		int gain = 0;
		
		for(Request request : problem.videoIdToRequests.get(videoId)) {
			EndPoint endpoint = problem.endpoints.get(request.Re);
			
			if(!endpoint.latencies.containsKey(cacheServer.serverId)) {
				continue; // the request's endpoint and the cache server are not connected 
			}
			
			// latency to current server
			int currentLatency = endpoint.Ld;
			if(request.serverUsed != null) {
				currentLatency = endpoint.latencies.get(request.serverUsed.serverId);
			}
			
			int newLatency = endpoint.latencies.get(cacheServer.serverId);
			
			if(newLatency < currentLatency) {
				gain += request.Rn * (currentLatency - newLatency);
			}
			
		}
		
		
		return gain;
	}
	
	
	private static int randomFromSet(HashSet<Integer> myHashSet, Random rn) {
		int size = myHashSet.size();
		int item = new Random().nextInt(size); // In real life, the Random object should be rather more shared than this
		int i = 0;
		for(Integer aaa : myHashSet)
		{
		    if (i == item)
		        return aaa;
		    i++;
		}
		return 0;
	}
	
    public static void doIt(String nameOfFile) throws IOException {
    	Algo algo = new Algo();
    	algo.problem = new Problem(new File("data/input/"+nameOfFile+".in"));
	    algo.caches = new HashMap<Integer, CacheServer>();
	    
	    File outFile = new File("data/output/manu_"+nameOfFile+"_1.out");
	    
	    DoAlgo1(algo, 1, 10);
	    
	    boolean correct = algo.checkCorrect();  
	    System.out.println(String.format("Correct: %b", correct));
	    int scoreFinal = algo.computeScoreFinal();
	    System.out.println(String.format("Score final: %d", scoreFinal));
	    
	    algo.printToFile(outFile);
    }
    
	public static void main(String[] args) throws IOException {
		//doIt("kittens");
		//doIt("me_at_the_zoo");
		//doIt("example");
		//doIt("trending_today");
		doIt("videos_worth_spreading");
		
	}
	
	
	
	
}
